import { TestBed } from '@angular/core/testing';

import { CapBookService } from './cap-book.service';

describe('CapBookService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapBookService = TestBed.get(CapBookService);
    expect(service).toBeTruthy();
  });
});
