import { Component, OnInit } from '@angular/core';
import { CapBookService } from '../services/cap-book.service';
import { Router } from '@angular/router';
import { Post } from '../post';
import { Profile } from '../profile';

@Component({
  selector: 'app-my-posts',
  templateUrl: './my-posts.component.html',
  styleUrls: ['./my-posts.component.css']
})
export class MyPostsComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  posts:Post[];
  profile:Profile;
  errorMessage:string;
  message:string;
  ngOnInit() {
      this.profile = JSON.parse(sessionStorage.getItem('profile'));
      this.capbookService.myPosts().subscribe(
        posts=>{
          this.posts=posts;
          this.profile = JSON.parse(sessionStorage.getItem('profile'));
          this.router.navigate(['/userProfile']);
        },
        errorMessage=>{
          this.errorMessage=errorMessage;
        })
    
  }

}
