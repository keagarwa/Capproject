import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectFriendComponent } from './select-friend.component';

describe('SelectFriendComponent', () => {
  let component: SelectFriendComponent;
  let fixture: ComponentFixture<SelectFriendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectFriendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectFriendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
