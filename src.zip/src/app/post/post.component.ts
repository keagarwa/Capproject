import { Component, OnInit } from '@angular/core';
import { Profile } from '../profile';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { CapBookService } from '../services/cap-book.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  
  profile:Profile;
  errorMessage:string; 
  constructor(private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) {}

  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
  }
 
  postForm=new FormGroup({
    postContent: new FormControl('')
  })
  onSubmit(){
    /* console.log('in submit of edit profile');
    this.capBookService.editProfile(this.postForm).subscribe(
      profile=>{
        console.log('in success of edit profile');
        this.profile=profile;
        sessionStorage.setItem('profile', JSON.stringify(profile));
        alert("You have successfully updated your profile");
        this.router.navigate(['/userProfile',profile]);
      },
      errorMessage=>{
        console.log('in error of edit profile');
        this.errorMessage=errorMessage;
        this.router.navigate(['/userProfile']);
        //alert("Please enter valid credentials");
      }) */
  }
}
