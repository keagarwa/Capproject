import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accept-friend',
  templateUrl: './accept-friend.component.html',
  styleUrls: ['./accept-friend.component.css']
})
export class AcceptFriendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
