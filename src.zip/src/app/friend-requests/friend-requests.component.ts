import { Component, OnInit } from '@angular/core';
import { CapBookService } from '../services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from '../profile';

@Component({
  selector: 'app-friend-requests',
  templateUrl: './friend-requests.component.html',
  styleUrls: ['./friend-requests.component.css']
})
export class FriendRequestsComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  friendRequests:Profile[];
  errorMessage:string;
  ngOnInit() {
      this.capbookService.myFriendRequests().subscribe(
        friendRequests=>{
          this.friendRequests=friendRequests;
        },
        errorMessage=>{
          this.errorMessage=errorMessage;
        })
    
  }
}
