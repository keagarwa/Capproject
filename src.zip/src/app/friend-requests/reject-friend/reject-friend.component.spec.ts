import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectFriendComponent } from './reject-friend.component';

describe('RejectFriendComponent', () => {
  let component: RejectFriendComponent;
  let fixture: ComponentFixture<RejectFriendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RejectFriendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectFriendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
