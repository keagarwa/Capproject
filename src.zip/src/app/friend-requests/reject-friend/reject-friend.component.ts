import { Component, OnInit } from '@angular/core';
import { CapBookService } from 'src/app/services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from 'src/app/profile';

@Component({
  selector: 'app-reject-friend',
  templateUrl: './reject-friend.component.html',
  styleUrls: ['./reject-friend.component.css']
})
export class RejectFriendComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  friendRequests:Profile[];
  errorMessage:string;
  ngOnInit() {
      this.capbookService.myFriendRequests().subscribe(
        friendRequests=>{
          this.friendRequests=friendRequests;
        },
        errorMessage=>{
          this.errorMessage=errorMessage;
        })
    
  }
}
