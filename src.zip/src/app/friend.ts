export interface Friend {
    friendId:number;
    fromUserId:string;
    toUserId:string;
}
